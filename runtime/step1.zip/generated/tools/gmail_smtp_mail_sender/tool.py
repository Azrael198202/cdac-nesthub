import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os

def run(payload):
    input_data = payload.get('input', payload)
    gmail_address = payload['connection']['gmail_address']
    from_address = payload['connection']['from_address']
    app_password = payload['secrets']['app_password']
    timeout_seconds = int(payload['connection'].get('timeout_seconds', 30))

    msg = MIMEMultipart()
    msg['From'] = from_address
    msg['To'] = input_data.get('to', '')
    msg['Cc'] = input_data.get('cc', '')
    msg['Bcc'] = input_data.get('bcc', '')
    msg['Subject'] = input_data.get('subject', 'No Subject')

    body = input_data.get('body', '')
    html_body = input_data.get('html_body', '')

    if body:
        msg.attach(MIMEText(body, 'plain'))
    if html_body:
        msg.attach(MIMEText(html_body, 'html'))

    attachments = input_data.get('attachments', [])
    for attachment in attachments:
        part = MIMEBase('application', 'octet-stream')
        with open(attachment, 'rb') as file:
            part.set_payload(file.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename={os.path.basename(attachment)}')
        msg.attach(part)

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465, timeout=timeout_seconds) as server:
            server.login(gmail_address, app_password)
            server.send_message(msg)
        return {
            'status': 'completed'
        }
    except Exception as e:
        return {
            'status': 'error',
            'data': str(e)
        }