import json
from tool import run

payload = {
    'input': {
        'to': 'sample@example.com',
        'cc': '',
        'bcc': '',
        'subject': 'Test Email',
        'body': 'This is a test email.',
        'html_body': '<b>This is a test email.</b>',
        'attachments': []
    },
    'connection': {
        'gmail_address': 'sample@example.com',
        'from_address': 'sample@example.com',
        'timeout_seconds': 30
    },
    'secrets': {
        'app_password': 'sample_app_password'
    }
}

result = run(payload)
assert json.dumps(result) is not None