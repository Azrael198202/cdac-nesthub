import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def send_email(input, connection, secrets):
    gmail_address = connection['gmail_address']
    from_address = connection['from_address']
    app_password = secrets['app_password']
    to = input.get('to', '')
    cc = input.get('cc', '')
    bcc = input.get('bcc', '')
    subject = input.get('subject', '')
    body = input.get('body', '')
    html_body = input.get('html_body', '')
    attachments = input.get('attachments', [])

    msg = MIMEMultipart()
    msg['From'] = from_address
    msg['To'] = to
    msg['Cc'] = cc
    msg['Bcc'] = bcc
    msg['Subject'] = subject

    if body:
        msg.attach(MIMEText(body, 'plain'))
    if html_body:
        msg.attach(MIMEText(html_body, 'html'))

    for attachment in attachments:
        part = MIMEBase('application', 'octet-stream')
        with open(attachment, 'rb') as f:
            part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename={attachment}')
        msg.attach(part)

    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    server.login(gmail_address, app_password)
    server.send_message(msg)
    server.quit()

    return {
        'status': 'success'
    }

# Generic runtime entrypoint adapter inserted by the capability generator.
# It preserves the generated implementation and only adapts the framework
# payload envelope to the callable declared by the manifest.
def run(payload=None):
    payload = payload if isinstance(payload, dict) else {}
    input_values = payload.get("input") if isinstance(payload.get("input"), dict) else payload
    connection_values = payload.get("connection") if isinstance(payload.get("connection"), dict) else {}
    secret_values = payload.get("secrets") if isinstance(payload.get("secrets"), dict) else {}
    _generated_delegate = send_email
    return _generated_delegate(input_values, connection_values, secret_values)

