import json
from tool import send_email

def test_send_email():
    input = {
        'to': 'sample@example.com',
        'cc': 'sample@example.com',
        'bcc': 'sample@example.com',
        'subject': 'Test Email',
        'body': 'This is a test email.',
        'html_body': '<p>This is a <b>test</b> email.</p>',
        'attachments': ['path/to/attachment1.pdf', 'path/to/attachment2.jpg']
    }

    connection = {
        'gmail_address': 'sample@example.com',
        'from_address': 'sample@example.com',
        'timeout_seconds': '30'
    }

    secrets = {
        'app_password': 'sample_app_password'
    }

    result = send_email(input, connection, secrets)
    assert result['status'] == 'success'
