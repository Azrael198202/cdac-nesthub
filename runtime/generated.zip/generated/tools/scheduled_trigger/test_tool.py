import json
from tool import run

def test_create_timer():
    payload = {
        'action': 'create',
        'timer_name': 'test_timer',
        'schedule': 'interval 1 hour',
        'target_type': 'agent',
        'target_agent_id': 'agent_123',
        'runtime_params': {'param1': 'value1'}
    }
    result = run(payload)
    assert result['status'] == 'success'
    assert 'test_timer' in result['data']

if __name__ == '__main__':
    test_create_timer()
