import json
import os
timers_dir = os.path.join(os.getcwd(), 'timers')

if not os.path.exists(timers_dir):
    os.makedirs(timers_dir)

def load_timers():
    timers = {}
    if os.path.exists(timers_file_path()):
        with open(timers_file_path(), 'r') as f:
            timers = json.load(f)
    return timers

def save_timers(timers):
    with open(timers_file_path(), 'w') as f:
        json.dump(timers, f, indent=4)

def timers_file_path():
    return os.path.join(timers_dir, 'timers.json')

def run(payload=None):
    if payload is None:
        payload = {}

    input_data = payload.get('input', {})

    action = input_data.get('action', '')
    timer_name = input_data.get('timer_name', '')
    schedule = input_data.get('schedule', '')
    target_type = input_data.get('target_type', '')
    target_agent_id = input_data.get('target_agent_id', '')
    runtime_params = input_data.get('runtime_params', {})

    timers = load_timers()

    if action == 'create':
        timers[timer_name] = {
            'enabled': True,
            'schedule': schedule,
            'target_type': target_type,
            'target_agent_id': target_agent_id,
            'runtime_params': runtime_params
        }
    elif action == 'list':
        return {'status': 'success', 'data': timers}
    elif action == 'enable':
        if timer_name in timers:
            timers[timer_name]['enabled'] = True
    elif action == 'disable':
        if timer_name in timers:
            timers[timer_name]['enabled'] = False
    elif action == 'delete':
        if timer_name in timers:
            del timers[timer_name]
    elif action == 'update':
        if timer_name in timers:
            timers[timer_name].update({
                'schedule': schedule,
                'target_type': target_type,
                'target_agent_id': target_agent_id,
                'runtime_params': runtime_params
            })

    save_timers(timers)

    return {'status': 'success', 'data': timers}
