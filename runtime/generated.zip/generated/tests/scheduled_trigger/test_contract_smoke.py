import importlib.util
import json
from pathlib import Path

TOOL_DIR = Path('E:\\pw\\cdac-nesthub\\runtime\\generated\\tools\\scheduled_trigger')
MANIFEST_PATH = Path('E:\\pw\\cdac-nesthub\\runtime\\generated\\tools\\scheduled_trigger\\manifest.json')


def test_runtime_contract_smoke():
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    entrypoint = manifest.get("entrypoint") or {}
    module_path = TOOL_DIR / str(entrypoint.get("module") or "tool.py")
    function_name = str(entrypoint.get("function") or "run")
    payload = manifest.get("verification_input") if isinstance(manifest.get("verification_input"), dict) else {}
    runtime = payload.setdefault("_runtime", {})
    if isinstance(runtime, dict):
        runtime.setdefault("dry_run", True)
    spec = importlib.util.spec_from_file_location("runtime_generated_tool_under_test", module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = getattr(module, function_name)(payload)
    json.dumps(result, ensure_ascii=False)
    assert isinstance(result, dict)
    status = str(result.get("status") or "").lower()
    assert status not in {"error", "failure", "failed"}, result
